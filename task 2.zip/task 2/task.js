document.addEventListener('DOMContentLoaded', () => {
    let timer = 0;
    let isRunning = false;
    let interval;
    let lapCounter = 1;

    const display = document.getElementById('display');
    const startPauseBtn = document.getElementById('startPauseBtn');
    const resetBtn = document.getElementById('resetBtn');
    const lapBtn = document.getElementById('lapBtn');
    const lapsList = document.getElementById('laps');

    /**
     * Formats the time in milliseconds to MM:SS:ms format.
     * @param {number} ms - The time in milliseconds.
     * @returns {string} The formatted time string.
     */
    function formatTime(ms) {
        let minutes = Math.floor(ms / 60000);
        let seconds = Math.floor((ms % 60000) / 1000);
        let milliseconds = Math.floor((ms % 1000) / 10);

        minutes = String(minutes).padStart(2, '0');
        seconds = String(seconds).padStart(2, '0');
        milliseconds = String(milliseconds).padStart(2, '0');

        return `${minutes}:${seconds}:${milliseconds}`;
    }

    /**
     * Updates the stopwatch display every 10 milliseconds.
     */
    function updateDisplay() {
        timer += 10;
        display.textContent = formatTime(timer);
    }

    // Event listener for the Start/Pause button
    startPauseBtn.addEventListener('click', () => {
        if (isRunning) {
            clearInterval(interval);
            startPauseBtn.textContent = 'Start';
            startPauseBtn.classList.remove('running');
        } else {
            interval = setInterval(updateDisplay, 10);
            startPauseBtn.textContent = 'Pause';
            startPauseBtn.classList.add('running');
        }
        isRunning = !isRunning;
    });

    // Event listener for the Reset button
    resetBtn.addEventListener('click', () => {
        clearInterval(interval);
        isRunning = false;
        timer = 0;
        lapCounter = 1;
        display.textContent = '00:00:00';
        startPauseBtn.textContent = 'Start';
        startPauseBtn.classList.remove('running');
        lapsList.innerHTML = '';
    });

    // Event listener for the Lap button
    lapBtn.addEventListener('click', () => {
        if (isRunning) {
            const lapTime = formatTime(timer);
            const lapItem = document.createElement('li');
            lapItem.textContent = `Lap ${lapCounter}: ${lapTime}`;
            lapsList.prepend(lapItem);
            lapCounter++;
        }
    });
});
